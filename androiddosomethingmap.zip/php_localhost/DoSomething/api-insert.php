<?php
	
	$host = "127.0.0.1";
	$user = "root";
	$pass = "12345";
	$db = "db_do_something";
	$con = mysql_connect($host, $user, $pass) or die("Error : ".mysql_error());
	$pilihDB = mysql_select_db($db, $con) or die("Error : ".mysql_error());
	
	$target_path = "upload/";
	   chmod($target_path, 0777);
       $target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 
       if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) 
       {
           echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
           "has been uploaded";
        }
        else
        {
            echo "There was an error uploading the file, please try again!";
        }

	$subject = $_POST['subject'];
	$ins_date = $_POST['ins_date'];
	$ins_time = $_POST['ins_time'];
	$longitude = $_POST['longitude'];
	$latitude = $_POST['latitude'];
	$address = $_POST['address'];
	$description = $_POST['description'];
	$image = $_POST['image'];
	$pieces = explode("/", $image);
	$images = $pieces[3];

	if($images <> '') {
	$perintahSQL = "INSERT INTO tbl_do_something(subject, ins_date, ins_time, longitude, latitude, address, description, image) VALUES ('$subject', '$ins_date', '$ins_time', '$longitude', '$latitude','$address','$description', '$images')";

	$eksekusiSQL = mysql_query($perintahSQL) or die("Error : ".mysql_error());

	if($eksekusiSQL){
		echo "Insert Map Successfuly";
	}else{
		echo "Insert Map Failed";
	}
}

?>
