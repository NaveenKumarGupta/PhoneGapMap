<?php

	$host = "127.0.0.1";
	$user = "root";
	$pass = "12345";
	$db = "db_do_something";
	$con = mysql_connect($host, $user, $pass) or die("Error : ".mysql_error());
	$pilihDB = mysql_select_db($db, $con) or die("Error : ".mysql_error());

	$perintahSQL = "SELECT * FROM tbl_do_something ORDER BY id DESC";
	$hasilSQL = mysql_query($perintahSQL);

	$rows = array();
	while($r = mysql_fetch_assoc($hasilSQL)){
		$rows[] = $r;
	}

	$data = "{DoSomething:".json_encode($rows)."}";
	echo $data;
	
?>
