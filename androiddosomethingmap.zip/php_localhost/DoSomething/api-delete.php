<?php
	$host = "127.0.0.1";
	$user = "root";
	$pass = "12345";
	$db = "db_do_something";
	$con = mysql_connect($host, $user, $pass) or die("Error : ".mysql_error());
	$pilihDB = mysql_select_db($db, $con) or die("Error : ".mysql_error());

	$id = $_POST['id'];
	$perintahSQL = "DELETE FROM tbl_do_something WHERE id = '$id'";
	$hasilSQL = mysql_query($perintahSQL);
	if($hasilSQL){
		$hasil = "Hapus Agenda Berhasil";
	}else{
		$hasil = "Hapus Agenda Gagal";
	}
	echo $hasil;
?>
