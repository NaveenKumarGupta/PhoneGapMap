-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 07, 2012 at 10:28 PM
-- Server version: 5.1.62
-- PHP Version: 5.3.6-13ubuntu3.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_do_something`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_do_something`
--

CREATE TABLE IF NOT EXISTS `tbl_do_something` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `ins_date` text NOT NULL,
  `ins_time` varchar(5) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbl_do_something`
--

INSERT INTO `tbl_do_something` (`id`, `subject`, `ins_date`, `ins_time`, `longitude`, `latitude`, `address`, `description`, `image`) VALUES
(17, 'Lunch Time...', '06-07-2012', '05:18', '-122.087095', '37.422005', 'Google Gate Bridge, Mountain View, CA 94043, United States', 'It''s time to lunch', 'pizza.jpg'),
(19, 'At Home', '07-07-2012', '07:55', '-122.100093', '37.422005', '882 Commercial St, Palo Alto, CA 94303, United States', 'take a rest..', 'home.jpg'),
(29, 'Working', '07-07-2012', '07:41', '-122.104094', '37.422005', '802-830 E Charleston Rd, Palo Alto, CA 94303, United States', 'Moneeey...moneeeey..\nmoneeeeey...', 'building.jpg'),
(24, 'Shopping time...', '07-07-2012', '08:17', '-122.12094', '37.422005', '3473 Waverley St, Palo Alto, CA 94306, United States', 'i want to buy something...', 'supermarket.jpg'),
(27, 'Vacation now..', '07-07-2012', '07:58', '-122.130093', '37.422005', '3100-3298 Alma St, Palo Alto, CA 94306, United States', 'Diving time..', 'beach.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
