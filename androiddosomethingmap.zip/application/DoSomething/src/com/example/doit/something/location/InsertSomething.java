package com.example.doit.something.location;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.*;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class InsertSomething extends android.support.v4.app.FragmentActivity {
	EditText txtSubject, txtMessage, txtImage;
	TextView lblLocation;
	Button btnInsertMap, back;
	ImageButton imageUpload;
	
	RelativeLayout lytMap;
	Calendar c;
	static final int DATE_DIALOG_ID = 0;
	
    //static LocationManager locManager_ini;    
    LocationListener locationListener;
    
    static String subject, ins_time, ins_date, message, image;
    double latitude, longitude;
    static String addressString;
    
    String url = "http://10.0.2.2/DoSomething/api-insert.php";	
	SimpleDateFormat time, date;
	
	String insertData;
	public static final int resultBackFile=1;
	public static final int resultBackCamera=2;
	private static final int SELECT_PICTURE = 1;
	private Uri imageUri;
	private String selectedImagePath;
    private String filemanagerstring;
	
	String imageFile, imagePath;
	File wallpaperDirectory;
	
	Location location;
	
	private GoogleMap mMap;
	
	UploadFile uf = new UploadFile();
	
	protected void onResume(){
		super.onResume();
		 posisiLokasi();
	}
	
	class MyInfoWindowAdapter implements InfoWindowAdapter{

        public final View myContentsView;
  
        MyInfoWindowAdapter(){
        	myContentsView = getLayoutInflater().inflate(R.layout.custom_info_window, null);
        }

		public View getInfoContents(Marker marker) {
			// TODO Auto-generated method stub	
			  TextView tvTitle = ((TextView)myContentsView.findViewById(R.id.title));
			  tvTitle.setText(marker.getTitle());
			  
			  return myContentsView;
		}

		public View getInfoWindow(Marker arg0) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	@SuppressLint("SdCardPath")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.insertsomething);
	
		txtSubject = (EditText)findViewById(R.id.txtSubject);
		txtMessage = (EditText)findViewById(R.id.txtMessage);
		txtImage = (EditText)findViewById(R.id.txtImage);
		imageUpload = (ImageButton)findViewById(R.id.imageUpload);		
		btnInsertMap = (Button)findViewById(R.id.btnInsertMap);
		lblLocation = (TextView)findViewById(R.id.lblLocation);
		back = (Button)findViewById(R.id.btnBack);
		
		wallpaperDirectory = new File("/sdcard/DoSomethingApp/");
        wallpaperDirectory.mkdirs();
		
		c = Calendar.getInstance();
        time = new SimpleDateFormat("HH:mm");
        date = new SimpleDateFormat("dd-MM-yyyy");
        ins_time = time.format(c.getTime());
        ins_date = date.format(c.getTime());
		
		btnInsertMap.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub			
				subject = txtSubject.getText().toString();
				message = txtMessage.getText().toString();
				image = txtImage.getText().toString();				
				
				if(subject.equals("")||message.equals("")||image.equals("")){
					Toast.makeText(InsertSomething.this, "Data not complete..", Toast.LENGTH_SHORT).show();
				}else{
					new InsertData().execute(); 
					//Toast.makeText(InsertSomething.this, ins_date+"\n"+ins_time+"\n"+subject+"\n"+message+"\n"+image+"\n"+latitude_in+"\n"+longitude+"\n"+"\n"+addressString, Toast.LENGTH_SHORT).show();
					//Toast.makeText(InsertSomething.this, String.valueOf(location.getLatitude())+"\n"+String.valueOf(location.getLongitude()), Toast.LENGTH_SHORT).show();
					//Toast.makeText(InsertSomething.this,image, Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		imageUpload.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				chooseImage();
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			finish();
			}
		});
		
		posisiLokasi();
	}
	
	public void posisiLokasi(){
		
	     // Do a null check to confirm that we have not already instantiated the map.
	     if (mMap == null) {
	         // Try to obtain the map from the SupportMapFragment.
	         mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
	                 .getMap();


	         mMap.setMyLocationEnabled(true);
	         mMap.getUiSettings().setZoomControlsEnabled(true);
	         mMap.getUiSettings().setCompassEnabled(true);
	         mMap.getUiSettings().setMyLocationButtonEnabled(true);
	         
	         mMap.getUiSettings().setRotateGesturesEnabled(true);
	         mMap.getUiSettings().setScrollGesturesEnabled(true);
	         mMap.getUiSettings().setTiltGesturesEnabled(true);
	         mMap.getUiSettings().setZoomGesturesEnabled(true);
	         mMap.setTrafficEnabled(true);
	         
	         mMap.setInfoWindowAdapter(new MyInfoWindowAdapter());
	         
	         // Check if we were successful in obtaining the map.
	         if (mMap != null) {		            
	             setUpMap();
	         }
	     }
	}
	     
	     public void setUpMap() {	 	

	    	 LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
	    	 Criteria criteria = new Criteria();
	    	 String provider = service.getBestProvider(criteria, false);
	    	 location = service.getLastKnownLocation(provider);
	    	 LatLng userLocation = new LatLng(location.getLatitude(),location.getLongitude());
	    	 
	    	//To Get Address
	    	   	Geocoder gc = new Geocoder(this, Locale.getDefault());
	    	    try {
	    	      List<Address> addresses = gc.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
	    	      StringBuilder sb = new StringBuilder();
	    	      if (addresses.size() > 0) {
	    	        Address address = addresses.get(0);

	    	        for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
	    	        sb.append(address.getAddressLine(i)).append(", "); 	
	    	        sb.append(address.getCountryName());
	    	        
	    	      }
	    	      addressString = sb.toString();
	    	    } catch (IOException e) {
	    	    }
	    		lblLocation.setText(addressString);
	    		//Toast.makeText(UpdateSomething.this,addressStringUp, Toast.LENGTH_SHORT).show();
	    		//To get Address
	    	 
	 		//BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
	 		mMap.addMarker(new MarkerOptions().position(userLocation).icon(BitmapDescriptorFactory.fromResource(R.drawable.doing)).
	 				title("Your Locations"));
	 		
	 		mMap.animateCamera(CameraUpdateFactory.newLatLng(userLocation));
	 		
	  }
	        
    	public void InsertSomethingData(){
			insertData = uf.uploadToServer(subject, ins_date, ins_time, String.valueOf(location.getLongitude()), String.valueOf(location.getLatitude()), addressString, message, imagePath, url);
    	}
    	/***/
    	
    	// code for get all data from sdcard
    	@SuppressWarnings("deprecation")
		public String getPath(Uri uri) {
    	        String[] projection = { MediaStore.Images.Media.DATA };
    	        Cursor cursor = managedQuery(uri, projection, null, null, null);
    	        if(cursor!=null)
    	        {   //HERE YOU WILL GET A NULLPOINTER IF CURSOR IS NULL
    	            //THIS CAN BE, IF YOU USED OI FILE MANAGER FOR PICKING THE MEDIA
    	            int column_index = cursor
    	            .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
    	            cursor.moveToFirst();
    	            return cursor.getString(column_index);
    	        }
    	        else return null;
    	    }
        
    	  // code for selected image from camera or album

    	public void chooseImage(){
        	final CharSequence[] AlbumPhoto = {"Image Album", "Take a photo"};
        	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setIcon(R.drawable.picture);
        	builder.setTitle("Select Photo");
        	builder.setItems(AlbumPhoto, new DialogInterface.OnClickListener() {
        	    public void onClick(DialogInterface dialog, int item) {
        	        //Toast.makeText(getApplicationContext(), FlowerPhoto[item], Toast.LENGTH_SHORT).show();
        	    	if(AlbumPhoto[item]=="Image Album"){
            			Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent,"Select Picture"), SELECT_PICTURE);
            		}else if(AlbumPhoto[item]=="Take a photo"){
            			takePhoto(resultBackCamera);
            		}
            		dialog.dismiss();
        	    }
        	});
        	AlertDialog alert = builder.create();
        	alert.show();       
    	}
    	
    	// code for save image from camera into /sdcard/DoSomethingApp
    		
    	 @SuppressLint("SdCardPath")
		public void takePhoto(int resultbackcamera2) {
    	    	String folder = "/sdcard/DoSomethingApp/";
    	        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
    	        Random generator = new Random();
    	        int n = 10000;
    	        n = generator.nextInt(n);
    	        String fname = "DoSomething-"+ n +".jpg";
    	        File photo = new File(folder, fname );
    	        intent.putExtra(MediaStore.EXTRA_OUTPUT,
    	                Uri.fromFile(photo));
    	        imageUri = Uri.fromFile(photo);
    	        startActivityForResult(intent, resultBackCamera);
    	    }
    	 
    	 protected void onActivityResult(int requestCode, int resultCode, Intent data)
    	    {
    	        switch(requestCode) {
    	        case resultBackFile:
    	        	if (resultCode == Activity.RESULT_OK) {
    	        		imageUpload = (ImageButton) findViewById(R.id.imageUpload);
    	        		txtImage = (EditText)findViewById(R.id.txtImage);
    	        		
    		        	imageUri = data.getData();
    		            //OI FILE Manager
    		            filemanagerstring = imageUri.getPath();
    		            //MEDIA GALLERY
    		            selectedImagePath = getPath(imageUri);
    		            //DEBUG PURPOSE - you can delete this if you want
    		            if(selectedImagePath!=null)
    		                System.out.println(selectedImagePath);
    		            else System.out.println("selectedImagePath is null");
    		            if(filemanagerstring!=null)
    		                System.out.println(filemanagerstring);
    		            else System.out.println("filemanagerstring is null");
    		            //NOW WE HAVE OUR WANTED STRING
    		            if(selectedImagePath!=null)
    		                System.out.println("selectedImagePath is the right one for you!");
    		            else
    		                System.out.println("filemanagerstring is the right one for you!");
    		            
    	            	BitmapFactory.Options options = new BitmapFactory.Options();
    	    	        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
    	    	        Bitmap bitmap = BitmapFactory.decodeFile(selectedImagePath, options);
    	    	        imageUpload.setImageBitmap(bitmap);
    	    	        imageUpload.setScaleType(ImageView.ScaleType.FIT_XY);
    		            //Toast.makeText(getApplicationContext(),selectedImagePath, Toast.LENGTH_SHORT).show();
    		            imagePath = selectedImagePath;
    		            txtImage.setText(imagePath);	
    		            
    		        	}
    	        	break;
    	        	
    	        case resultBackCamera:
    	        	if (resultCode == Activity.RESULT_OK) {
    	                Uri selectedImage = imageUri;
    	                getContentResolver().notifyChange(selectedImage, null);
    	                imageUpload = (ImageButton) findViewById(R.id.imageUpload);
    	                txtImage = (EditText)findViewById(R.id.txtImage);
    	                
    	                ContentResolver cr = getContentResolver();
    	                Bitmap bitmap;
    	                try {
    	                     bitmap = android.provider.MediaStore.Images.Media
    	                     .getBitmap(cr, selectedImage);
    	                    imageUpload.setImageBitmap(bitmap);
    	                    imageUpload.setScaleType(ImageView.ScaleType.FIT_XY);
    	                    //Toast.makeText(this, selectedImage.toString(), Toast.LENGTH_LONG).show();
    	                } catch (Exception e) {
    	                    //Toast.makeText(this, "Failed to load", Toast.LENGTH_SHORT).show();
    	                    Log.e("Camera", e.toString());
    	                }
    	                imagePath = selectedImage.toString();
    	                imagePath = imagePath.substring(7);
    	                txtImage.setText(imagePath);	
    	            }
    	        	break;
    	        }    
    	    }
    	 
    	 @Override
    		public void onConfigurationChanged(final Configuration newConfig)
    		{
    		    // Ignore orientation change to keep activity from restarting
    		    super.onConfigurationChanged(newConfig);
    		}
    		public class InsertData extends AsyncTask<Void, Void, Void> {
    			ProgressDialog dialog;
    			
    			@Override
    			 protected void onPreExecute() {
    			  // TODO Auto-generated method stub
    				 dialog= ProgressDialog.show(InsertSomething.this, "", 
    		                 "Insert data..., please wait...", true);
    			 }

    			 @Override
    			 protected Void doInBackground(Void... params) {
    			  // TODO Auto-generated method stub
    				 //InsertData();
    				 InsertSomethingData();
    			  return null;
    			 }

    			@Override
    			protected void onPostExecute(Void result) {
    				// TODO Auto-generated method stub
    				dialog.dismiss();
    				Toast.makeText(InsertSomething.this, "Insert Data Succesfuly", Toast.LENGTH_SHORT).show();
    			}
    		}
}

