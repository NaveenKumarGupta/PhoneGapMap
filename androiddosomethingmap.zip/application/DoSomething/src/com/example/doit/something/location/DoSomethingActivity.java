package com.example.doit.something.location;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import doit.something.action.*;

public class DoSomethingActivity extends Activity {
	Button btnInsert, btnBack, btnLooking;
	LocationManager locManager;
	static int[] id;
	static String[] subject;
	static String[] message;
	static String[] ins_date;
	static String[] ins_time;
	static double[] latitude;
	static double[] longitude;
	static String[] image;
	static String[] address;
	
	String connect = "";
	String value="";
	String alert= "No Internet Connection..";
	String delete="";
	String idString;
	
	private int mSelectedRow = 0;
	
	ListView l1;
	EfficientAdapter ea;
	
	//link localhost location for php in directory
	String url="http://10.0.2.2/DoSomething/api-select.php";
	static String urlImage="http://10.0.2.2/DoSomething/upload/";
	String urlDelete="http://10.0.2.2/DoSomething/api-delete.php";
	
	JSONObject JobjectDoSomething;
	JSONArray userArrayDoSomething;
	
	private static final int ID_MAP = 1;
	private static final int ID_UPDATE = 2;
	private static final int ID_DELETE = 3;
	
	private ProgressBar mProgress;
	
	@Override
	protected void onResume(){
		super.onResume();
		new LoadListView().execute();
	    ea.notifyDataSetChanged();
	    ea.notifyDataSetInvalidated();
	    l1.invalidateViews();
	}
	
	private static class EfficientAdapter extends BaseAdapter {
		private LayoutInflater mInflater;

		public EfficientAdapter(Context context) {
			mInflater = LayoutInflater.from(context);
			
		}

		public int getCount() {
			return subject.length;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		@SuppressWarnings("deprecation")
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_row, null);
				holder = new ViewHolder();
				holder.lblSubject = (TextView) convertView.findViewById(R.id.lblSubject);
				holder.lblTime = (TextView) convertView.findViewById(R.id.lblTime);
				holder.lblImage = (ImageView) convertView.findViewById(R.id.imgDoSomething);
				

				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			
			holder.lblSubject.setText(subject[position]);
			holder.lblTime.setText("Time : "+ins_time[position]+" "+"Date : "+ins_date[position]);
			
			String image_URL = urlImage+image[position];
			holder.lblImage.setBackgroundDrawable(loadImageFromURL(image_URL));
	        holder.lblImage.setScaleType(ImageView.ScaleType.FIT_XY);
			
			//Bitmap bitmap = getBitmap(image_URL);
			//holder.lblImage.setImageBitmap(bitmap);
			//holder.lblImage.setScaleType(ImageView.ScaleType.FIT_XY);
			
			/*BitmapFactory.Options options = new BitmapFactory.Options();
			options.inSampleSize = 8;
	        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
	        Bitmap bitmap = LoadImage(image_URL, options);
	        holder.lblImage.setImageBitmap(bitmap);
	        holder.lblImage.setScaleType(ImageView.ScaleType.FIT_XY);*/
			
			return convertView;
		}

		static class ViewHolder {
			TextView lblSubject;
			TextView lblTime;
			ImageView lblImage;
		}
	}
	
	public static Bitmap getBitmap(String bitmapUrl) {
  	  try {
  	    URL url = new URL(bitmapUrl);
  	    return BitmapFactory.decodeStream(url.openConnection().getInputStream()); 
  	  }
  	  catch(Exception ex) {return null;}
  	}

	
	private static Drawable loadImageFromURL(String url)
    {
    try
    {
    InputStream is = (InputStream) new URL(url).getContent();
    Drawable d = Drawable.createFromStream(is, "src");
    return d;
    }catch (Exception e) {
    System.out.println(e);
    return null;
    }
 }

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		btnInsert = (Button)findViewById(R.id.btnInsert);
		btnBack = (Button)findViewById(R.id.btnBack);
		btnLooking = (Button)findViewById(R.id.btnLooking);
		
		mProgress = (ProgressBar) findViewById(R.id.progress_bar);
		
		l1 = (ListView) findViewById(R.id.ListMap);	
		ea = new EfficientAdapter(this);
		l1.setFastScrollEnabled(true);
		
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = 
			        new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		
		//check Internet Connection
		alert = checkInternet();
				if(alert.equalsIgnoreCase("No Internet Connection..")){
					Toast.makeText(DoSomethingActivity.this, "No Internet connections", Toast.LENGTH_LONG).show();
					finish();
				}
		
		ActionItem addItem 		= new ActionItem(ID_MAP, "Map", getResources().getDrawable(R.drawable.map));
		ActionItem acceptItem 	= new ActionItem(ID_UPDATE, "Update", getResources().getDrawable(R.drawable.update));
        ActionItem uploadItem 	= new ActionItem(ID_DELETE, "Delete", getResources().getDrawable(R.drawable.delete));
		final QuickAction mQuickAction 	= new QuickAction(this);
		
		mQuickAction.addActionItem(addItem);
		mQuickAction.addActionItem(acceptItem);
		mQuickAction.addActionItem(uploadItem);
		
		//setup the action item click listener
				mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() {
					public void onItemClick(QuickAction quickAction, int position, int actionId) {
						//ActionItem actionItem = quickAction.getActionItem(position);
						if (actionId == ID_MAP) { //Add item selected
							//Toast.makeText(getApplicationContext(), "Add item selected on row " + mSelectedRow, Toast.LENGTH_SHORT).show();
							Intent i = new Intent(DoSomethingActivity.this,MapSomething.class);
							i.putExtra("id", id[mSelectedRow]);
							i.putExtra("subject", subject[mSelectedRow]);
							i.putExtra("ins_date", ins_date[mSelectedRow]);
							i.putExtra("ins_time", ins_time[mSelectedRow]);
							i.putExtra("longitude", longitude[mSelectedRow]);
							i.putExtra("latitude", latitude[mSelectedRow]);
							i.putExtra("address", address[mSelectedRow]);
							i.putExtra("description", message[mSelectedRow]);
							i.putExtra("image", image[mSelectedRow]);
					    	startActivity(i);
						}else if(actionId == ID_UPDATE){
							Intent i_send = new Intent(DoSomethingActivity.this,UpdateSomething.class);
							i_send.putExtra("id", id[mSelectedRow]);
							i_send.putExtra("subject", subject[mSelectedRow]);
							i_send.putExtra("ins_date", ins_date[mSelectedRow]);
							i_send.putExtra("ins_time", ins_time[mSelectedRow]);
							i_send.putExtra("longitude", longitude[mSelectedRow]);
							i_send.putExtra("latitude", latitude[mSelectedRow]);
							i_send.putExtra("address", address[mSelectedRow]);
							i_send.putExtra("description", message[mSelectedRow]);
							i_send.putExtra("image", image[mSelectedRow]);
					    	startActivity(i_send);
						}else if(actionId == ID_DELETE){
							//Toast.makeText(getApplicationContext(), actionItem.getTitle() + " item selected on row ", Toast.LENGTH_SHORT).show();
							idString = String.valueOf(id[mSelectedRow]);
							deleteDoSomething();							
						}
					}
				});
				
				
		
		mQuickAction.setOnDismissListener(new PopupWindow.OnDismissListener() {			
			public void onDismiss() {
			}
		});
		
		connect = checkInternet();
		if(connect.equalsIgnoreCase("No Internet Connection")){
			AlertDialog(alert);
		}else{
			//cekGPS();
		}
		
		l1.setOnItemClickListener(new OnItemClickListener() {
		    public void onItemClick(AdapterView<?> parent, View view,
		        int position, long id) {
		      // When clicked, show a toast with the TextView text
		    	mSelectedRow = position;
		    	mQuickAction.show(view);
		    }
		  });
		
		btnInsert.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(DoSomethingActivity.this, InsertSomething.class);
				startActivity(i);
			}
		});
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				exitDoSomething();
			}
		});
		
		btnLooking.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(DoSomethingActivity.this, LookingAllMapDoSomething.class);
				i.putExtra("id", id);
				i.putExtra("subject", subject);
				i.putExtra("ins_date", ins_date);
				i.putExtra("ins_time", ins_time);
				i.putExtra("longitude", longitude);
				i.putExtra("latitude", latitude);
				i.putExtra("address", address);
				i.putExtra("description", message);
				i.putExtra("image", image);
				startActivity(i);
			}
		});
	}
	
	//alert
	public void AlertDialog(String pesan){
		Toast.makeText(this, pesan, Toast.LENGTH_SHORT).show();
	}
	
	// Alert for close this app
	private void exitDoSomething(){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setIcon(R.drawable.main);
    	builder.setTitle("Exit Application");
		builder.setMessage("Are you sure you wanna exit this app?")
		     .setCancelable(false)
		     .setPositiveButton("Yes",
		          new DialogInterface.OnClickListener(){
		          public void onClick(DialogInterface dialog, int id){
		        	  finish();
		          }
		     })
		     .setNegativeButton("No", new DialogInterface.OnClickListener() {
        	public void onClick(DialogInterface dialog, int id) {
    	        }
        	
    	        });
        
		AlertDialog alert = builder.create();
		alert.show();
		}
	
	// for check GPS
	public void cekGPS(){
		locManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		if (!locManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
		      createGpsDisabledAlert();
		}
	}
	
	// alert for activate GPS
	private void createGpsDisabledAlert(){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Your GPS is not Activate. Please Enable your GPS to use this Application.")
		     .setCancelable(false)
		     .setPositiveButton("Enable GPS",
		          new DialogInterface.OnClickListener(){
		          public void onClick(DialogInterface dialog, int id){
		               showGpsOptions();
		          }
		     });
		AlertDialog alert = builder.create();
		alert.show();
		}
	
	private void showGpsOptions(){
		Intent gpsOptionsIntent = new Intent(
				android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		startActivity(gpsOptionsIntent);
	}

	// load data from mysql using asyntask 
	@Override
	public void onConfigurationChanged(final Configuration newConfig)
	{
	    // Ignore orientation change to keep activity from restarting
	    super.onConfigurationChanged(newConfig);
	}
	
	public class LoadListView extends
	  AsyncTask<Void, Void, Void> {

		int myProgress;
		@Override
		 protected void onPreExecute() {
		  // TODO Auto-generated method stub			 
			 myProgress = 0;
		 }

		 @Override
		 protected Void doInBackground(Void... params) {
		  // TODO Auto-generated method stub
			 checkRun();
		  return null;
		 }

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			l1.setAdapter(ea);
			mProgress.setVisibility(View.GONE);
		}
	}
	
	public void checkRun(){
		value = getRequest(url);
		try {
			parseJSON();
			getJSONData();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	// method for check internet connection
	public String checkInternet(){
		String connect = "";
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getActiveNetworkInfo();
		
		if(ni == null){
			connect = "No Internet Connection..";
		}
		return connect;
	}
	
	public String parseJSON() throws JSONException{
		JobjectDoSomething = new JSONObject(value);
		userArrayDoSomething = JobjectDoSomething.getJSONArray("DoSomething");
		
		if(userArrayDoSomething.length() !=0){
			return "Success";
		}else{
			return "Failed";
		}
	}
	
	public void getJSONData()throws JSONException{
		id = new int[userArrayDoSomething.length()];
		subject = new String[userArrayDoSomething.length()];
		ins_date = new String[userArrayDoSomething.length()];
		ins_time = new String[userArrayDoSomething.length()];
		message = new String[userArrayDoSomething.length()];
		longitude = new double[userArrayDoSomething.length()];
		latitude = new double[userArrayDoSomething.length()];
		address = new String[userArrayDoSomething.length()];
		image = new String[userArrayDoSomething.length()];
		
		for(int i=0; i<userArrayDoSomething.length(); i++){
			id[i]= Integer.parseInt(userArrayDoSomething.getJSONObject(i).getString("id"));
			subject[i]= userArrayDoSomething.getJSONObject(i).getString("subject");
			ins_date[i]= userArrayDoSomething.getJSONObject(i).getString("ins_date");
			ins_time[i]= userArrayDoSomething.getJSONObject(i).getString("ins_time");
			longitude[i]= Double.parseDouble(userArrayDoSomething.getJSONObject(i).getString("longitude"));
			latitude[i]= Double.parseDouble(userArrayDoSomething.getJSONObject(i).getString("latitude"));
			address[i]= userArrayDoSomething.getJSONObject(i).getString("address");
			message[i]= userArrayDoSomething.getJSONObject(i).getString("description");
			image[i]= userArrayDoSomething.getJSONObject(i).getString("image");
		}
		
	}		   
	
	public String getRequest(String Url){
		String hasil = "";
		Log.d("getRequest",Url);
        HttpClient client = new DefaultHttpClient();
        HttpPost request = new HttpPost(Url);
        
        try{
        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(0);
            request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
        	HttpResponse response = client.execute(request);
            hasil = request(response);
        }catch(Exception ex){
        	hasil = "Failed Connect to server!";
        }
        return hasil;
     }
	
	public String getRequestDelete(String id, String Url){
		String hasil = "";
		Log.d("getRequest",Url);
		HttpClient client = new DefaultHttpClient();
	    HttpPost request = new HttpPost(Url);
	    
	    try{
	    	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
	    	nameValuePairs.add(new BasicNameValuePair("id", id));
	        request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	    	HttpResponse response = client.execute(request);
	        hasil = request(response);
	    }catch(Exception ex){
	    	hasil = "Failed Connect to server!";
	    }
	    return hasil;
		}

	public static String request(HttpResponse response){
	    String result = "";
	    try{
	        InputStream in = response.getEntity().getContent();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
	        StringBuilder str = new StringBuilder();
	        String line = null;
	        while((line = reader.readLine()) != null){
	            str.append(line + "\n");
	        }
	        in.close();
	        result = str.toString();
	    }catch(Exception ex){
	        result = "Error";
	    }
	    return result;
	}
	
	// method to delete data
	public void delete(){	
		delete = getRequestDelete(idString, urlDelete);
	}
	
	//asytask to delete data
	public class DeleteListView extends
	  AsyncTask<Void, Void, Void> {
		
		ProgressDialog dialog;
		@Override
		 protected void onPreExecute() {
		  // TODO Auto-generated method stub
			 dialog= ProgressDialog.show(DoSomethingActivity.this, "", 
	                 "Delete data..., please wait...", true);
		 }

		 @Override
		 protected Void doInBackground(Void... params) {
		  // TODO Auto-generated method stub
			 delete();
		  return null;
		 }

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			new LoadListView().execute();
			dialog.dismiss();	
		}
	}
	
	// Alert for close this app
		private void deleteDoSomething(){
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setIcon(R.drawable.delete);
	    	builder.setTitle("Delete List Activity");
			builder.setMessage("Are you sure you wanna delete this list?")
			     .setCancelable(false)
			     .setPositiveButton("Yes",
			          new DialogInterface.OnClickListener(){
			          public void onClick(DialogInterface dialog, int id){
			        	  new DeleteListView().execute();
			          }
			     })
			     .setNegativeButton("No", new DialogInterface.OnClickListener() {
	        	public void onClick(DialogInterface dialog, int id) {
	    	        }
	        	
	    	        });
	        
			AlertDialog alert = builder.create();
			alert.show();
			}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	exitDoSomething();
	        return true;		        
	    }
	    return super.onKeyDown(keyCode, event);
	}

}