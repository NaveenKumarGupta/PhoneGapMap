package com.example.doit.something.location;

import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import java.io.InputStream;
import java.net.URL;
import java.util.List;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

public class LookingAllMapDoSomething extends android.support.v4.app.FragmentActivity {
	
	MapView peta;
	MapController mc;
	RelativeLayout lytPeta_all;
	View zoomButton;
	//static LocationManager locManager;
    LocationListener locationListener;
    
    //link localhost location for php in directory
    String urlImageAll="http://10.0.2.2/DoSomething/upload/";
    String url="http://10.0.2.2/DoSomething/api-select.php";
	
	String valueList="";
	
	static int[] id;
	static String[] subject;
	static String[] message;
	static String[] ins_date;
	static String[] ins_time;
	static double[] latitude;
	static double[] longitude;
	static String[] image;
	static String[] address;
	
	GeoPoint point;
	List<Overlay> mapOverlays;
	Drawable drawable;
	
	LocationManager locationManager;
	Location location;
	
	private GoogleMap mMap;
	Marker temp;
	Marker map;
	
	/*private static final LatLng BRISBANE = new LatLng(-6.158305, 106.751175);
    private static final LatLng MELBOURNE = new LatLng(-6.268888, 106.782761);
    private static final LatLng SYDNEY = new LatLng(-6.242951, 106.70723);
    private static final LatLng ADELAIDE = new LatLng(-6.133728, 106.861038);
    private static final LatLng PERTH = new LatLng(-6.171958, 106.825333);
    */
    /*private Marker mPerth;
    private Marker mSydney;
    private Marker mBrisbane;
    private Marker mAdelaide;
    private Marker mMelbourne;
    private TextView mTopText;
	*/
	class MyInfoWindowAdapter implements InfoWindowAdapter{

        public View myContentsView;
  
        MyInfoWindowAdapter(){
        	myContentsView = getLayoutInflater().inflate(R.layout.balloon_overlay, null);
        }

		public View getInfoContents(Marker marker) {
			
			// TODO Auto-generated method stub
			  /*TextView tvTitle = ((TextView)myContentsView.findViewById(R.id.balloon_item_title));
			  tvTitle.setText(marker.getTitle());
			  TextView tvSnippet = ((TextView)myContentsView.findViewById(R.id.balloon_item_snippet));
			  tvSnippet.setText(marker.getSnippet());
			  
			  ImageView ivIcon = ((ImageView)myContentsView.findViewById(R.id.balloon_item_image));
			  ivIcon.setImageDrawable(getResources().getDrawable(R.drawable.thumbnail));
			  //ivIcon.setBackgroundDrawable(loadImageFromURL(urlImageAll+image));
		      //ivIcon.setScaleType(ImageView.ScaleType.FIT_XY);
			*/
			
			  render(marker, myContentsView);
			  return myContentsView;
		}

		public View getInfoWindow(Marker marker) {
			// TODO Auto-generated method stub
			return null;
		}
		
		 @SuppressWarnings({ "deprecation"})
		private void render(Marker marker, View view) {
			 //Drawable badge = null;		
			 /*for(int i=0 ; i< id.length ; i++ ){
			 if (marker.equals(mBrisbane)) {
	                badge = loadImageFromURL(urlImageAll+image[0]);
	            } else if (marker.equals(mAdelaide)) {
	                badge = loadImageFromURL(urlImageAll+image[1]);
	            } else if (marker.equals(mSydney)) {
	                badge = loadImageFromURL(urlImageAll+image[2]);
	            } else if (marker.equals(mMelbourne)) {
	                badge = loadImageFromURL(urlImageAll+image[3]);
	            } else if (marker.equals(mPerth)) {
	                badge = loadImageFromURL(urlImageAll+image[4]);
	            } 
			 ((ImageView) view.findViewById(R.id.balloon_item_image)).setBackgroundDrawable(badge);
			 }*/
			/*for(int i=0 ; i< id.length ; i++ ){
				 if (marker.equals(mBrisbane)) {
			      badge = loadImageFromURL(urlImageAll+image[i]);
				 }
			      ((ImageView) view.findViewById(R.id.balloon_item_image)).setBackgroundDrawable(badge);
				}
			*/
			((ImageView) view.findViewById(R.id.balloon_item_image)).setImageDrawable(getResources().getDrawable(R.drawable.thumbnail));
			
			 String title = marker.getTitle();
	            TextView titleUi = ((TextView) view.findViewById(R.id.balloon_item_title));
	            if (title != null) {
	                // Spannable string allows us to edit the formatting of the text.
	                SpannableString titleText = new SpannableString(title);
	                titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
	                titleUi.setText(titleText);
	            } else {
	                titleUi.setText("");
	            }

	            String snippet = marker.getSnippet();
	            TextView snippetUi = ((TextView) view.findViewById(R.id.balloon_item_snippet));
	            if (snippet != null) {
	                SpannableString snippetText = new SpannableString(snippet);
	                snippetText.setSpan(new ForegroundColorSpan(Color.MAGENTA), 0, 10, 0);
	                snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 12, 21, 0);
	                snippetUi.setText(snippetText);
	            } else {
	                snippetUi.setText("");
	            }
		 }
	}
    
    protected void onResume(){
		super.onResume();
		posisiLokasi();
    }
    
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lookingallmap);
		
		
	}
	
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public static Bitmap getBitmap(String bitmapUrl) {
	  	  try {
	  	    URL url = new URL(bitmapUrl);
	  	    return BitmapFactory.decodeStream(url.openConnection().getInputStream()); 
	  	  }
	  	  catch(Exception ex) {return null;}
	  	}

		
		public static Drawable loadImageFromURL(String url)
	    {
	    try
	    {
	    InputStream is = (InputStream) new URL(url).getContent();
	    Drawable d = Drawable.createFromStream(is, "src");
	    return d;
	    }catch (Exception e) {
	    System.out.println(e);
	    return null;
	    }
	   }

	
	public void posisiLokasi(){
		
		if (mMap == null) {
	         // Try to obtain the map from the SupportMapFragment.
	         mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
	                 .getMap();

	         mMap.setMyLocationEnabled(true);
	         mMap.getUiSettings().setZoomControlsEnabled(true);
	         mMap.getUiSettings().setCompassEnabled(true);
	         mMap.getUiSettings().setMyLocationButtonEnabled(true);
	         
	         mMap.getUiSettings().setRotateGesturesEnabled(true);
	         mMap.getUiSettings().setScrollGesturesEnabled(true);
	         mMap.getUiSettings().setTiltGesturesEnabled(true);
	         mMap.getUiSettings().setZoomGesturesEnabled(true);
	         mMap.setTrafficEnabled(true);
	         
	         mMap.setInfoWindowAdapter(new MyInfoWindowAdapter());
	         
	         
	         // Check if we were successful in obtaining the map.
	         if (mMap != null) {
	             setUpMap();
	         }
	     }

	}
	
	public void setUpMap() {
		Intent i_get = getIntent();
		id = i_get.getIntArrayExtra("id");
		subject = i_get.getStringArrayExtra("subject");
		ins_date = i_get.getStringArrayExtra("ins_date");
		ins_time = i_get.getStringArrayExtra("ins_time");
		longitude = i_get.getDoubleArrayExtra("longitude");
		latitude = i_get.getDoubleArrayExtra("latitude");
		address = i_get.getStringArrayExtra("address");
		message = i_get.getStringArrayExtra("description");
		image = i_get.getStringArrayExtra("image");
		
		/*final LatLng HAMBURG = new LatLng(-6.176737, 106.811028);
		mMap.addMarker(new MarkerOptions().position(HAMBURG)
		        .title("Hamburg"));*/
	 	
		/*for(int i=0 ; i< id.length ; i++ ){
		BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
		temp = mMap.addMarker(new MarkerOptions().position(new LatLng(latitude[i], longitude[i])).icon(bitmapDescriptor).
				title("Name : "+subject[i]+"\n" + "Time : " + ins_time[i]+" Date : "+ins_date[i]+"\n"+"Address : "+address[i]+"\n"+"Description : "+message[i])
				.draggable(true));
		//BitmapDescriptorFactory.fromBitmap(getBitmap(urlImageAll+image[i])
		}
		*/
		for(int i=0 ; i< id.length ; i++ ){
		  mMap.addMarker(new MarkerOptions()
         .position(new LatLng(latitude[i], longitude[i]))
         .title(subject[i])
         .snippet("Time : " + ins_time[i]+" Date : "+ins_date[i]+"\n"+"Address : "+address[i]+"\n"+"Description : "+message[i])
         .icon(BitmapDescriptorFactory.fromResource(R.drawable.doing)));
		}
		/*
		 // Uses a custom icon.
		 mSydney = mMap.addMarker(new MarkerOptions()
		         .position(SYDNEY)
		         .title("Sydney")
		         .snippet("Population: 4,627,300")		         );
		
		 // Creates a draggable marker. Long press to drag.
		 mMelbourne = mMap.addMarker(new MarkerOptions()
		         .position(MELBOURNE)
		         .title("Melbourne")
		         .snippet("Population: 4,137,400")
		         .draggable(true));
		
		 // A few more markers for good measure.
		 mPerth = mMap.addMarker(new MarkerOptions()
		         .position(PERTH)
		         .title("Perth")
		         .snippet("Population: 1,738,800"));
		 mAdelaide = mMap.addMarker(new MarkerOptions()
		         .position(ADELAIDE)
		         .title("Adelaide")
		         .snippet("Population: 1,213,000"));
		*/
 }
	
	public void onInfoWindowClick(Marker marker) {
		Toast.makeText(this, String.valueOf(marker.equals(temp)), Toast.LENGTH_LONG).show();
    }
		
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {
		    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
		    	finish();
		        return true;		        
		    }
		    return super.onKeyDown(keyCode, event);
		}
}
