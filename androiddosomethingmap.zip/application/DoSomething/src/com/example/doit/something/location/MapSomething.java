package com.example.doit.something.location;

import java.io.InputStream;
import java.net.URL;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapSomething extends android.support.v4.app.FragmentActivity {

	static String subject_in, ins_date_in, ins_time_in, message_in, image_in, address_in;
	static double latitude_in, longitude_in;
  //link localhost location for php in directory
    String urlImage="http://10.0.2.2/DoSomething/upload/";

	private GoogleMap mMap;
	
	
	class MyInfoWindowAdapter implements InfoWindowAdapter{

        public final View myContentsView;
  
        MyInfoWindowAdapter(){
        	myContentsView = getLayoutInflater().inflate(R.layout.balloon_overlay, null);
        }

		@SuppressWarnings("deprecation")
		public View getInfoContents(Marker marker) {
			// TODO Auto-generated method stub			
			  TextView tvTitle = ((TextView)myContentsView.findViewById(R.id.balloon_item_title));
			  tvTitle.setText(marker.getTitle());
			  TextView tvSnippet = ((TextView)myContentsView.findViewById(R.id.balloon_item_snippet));
			  tvSnippet.setText(marker.getSnippet());
			  
			  ImageView ivIcon = ((ImageView)myContentsView.findViewById(R.id.balloon_item_image));
			   //ivIcon.setImageDrawable(getResources().getDrawable(android.R.drawable.ic_menu_gallery));
		        ivIcon.setBackgroundDrawable(loadImageFromURL(urlImage+image_in));
		        ivIcon.setScaleType(ImageView.ScaleType.FIT_XY);
			  
			  return myContentsView;
		}

		public View getInfoWindow(Marker arg0) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
		public static Bitmap getBitmap(String bitmapUrl) {
	  	  try {
	  	    URL url = new URL(bitmapUrl);
	  	    return BitmapFactory.decodeStream(url.openConnection().getInputStream()); 
	  	  }
	  	  catch(Exception ex) {return null;}
	  	}

		
		public static Drawable loadImageFromURL(String url)
	    {
	    try
	    {
	    InputStream is = (InputStream) new URL(url).getContent();
	    Drawable d = Drawable.createFromStream(is, "src");
	    return d;
	    }catch (Exception e) {
	    System.out.println(e);
	    return null;
	    }
	   }
    
	 
	 protected void onResume() {
	     super.onResume();
	     posisiLokasi();
	 }
    
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mapsomething);
		posisiLokasi();

	}	
	
	
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
		
	
	/*public void inisialisasiPeta(){
		peta = (MapView)findViewById(R.id.map2);
		peta.setBuiltInZoomControls(true);
		mc = peta.getController();
		mc.setZoom(15);
		
		if(peta.isSatellite()){
	        peta.setSatellite(false);
	      }else{
	        peta.setStreetView(false);
	        peta.setSatellite(true);
	      }

	}*/
	
	public void posisiLokasi(){
		
		     // Do a null check to confirm that we have not already instantiated the map.
		     if (mMap == null) {
		         // Try to obtain the map from the SupportMapFragment.
		         mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
		                 .getMap();

		         mMap.setMyLocationEnabled(true);
		         mMap.getUiSettings().setZoomControlsEnabled(true);
		         mMap.getUiSettings().setCompassEnabled(true);
		         mMap.getUiSettings().setMyLocationButtonEnabled(true);
		         
		         mMap.getUiSettings().setRotateGesturesEnabled(true);
		         mMap.getUiSettings().setScrollGesturesEnabled(true);
		         mMap.getUiSettings().setTiltGesturesEnabled(true);
		         mMap.getUiSettings().setZoomGesturesEnabled(true);
		         mMap.setTrafficEnabled(true);
		         
		         mMap.setInfoWindowAdapter(new MyInfoWindowAdapter());
		         
		         
		         // Check if we were successful in obtaining the map.
		         if (mMap != null) {
		             setUpMap();
		         }
		     }
		
	        /*GeoPoint point = new GeoPoint((int) (latitude_in *1E6),(int) (longitude_in * 1E6));
	        List<Overlay> mapOverlays = peta.getOverlays();
	        Drawable drawable = getResources().getDrawable(R.drawable.doing);	
	        CustomItemizedOverlay<CustomOverlayItem> itemizedOverlay = new CustomItemizedOverlay<CustomOverlayItem>(drawable, peta);		
			CustomOverlayItem overlayItem = new CustomOverlayItem(point, subject_in, 
					"Time : " + ins_time_in+" Date : "+ins_date_in+"\n"+"Address : "+address_in+"\n"+"Description : "+message_in, 
					urlImage+image_in);
			itemizedOverlay.addOverlay(overlayItem);
			
			mapOverlays.add(itemizedOverlay);
			
			MapController mapController = peta.getController();
			mapController.setCenter(point);
			*/
	}
	
	public void setUpMap() {
		Intent i_get = getIntent();
		subject_in = i_get.getStringExtra("subject");
		ins_date_in = i_get.getStringExtra("ins_date");
		ins_time_in = i_get.getStringExtra("ins_time");
		longitude_in = i_get.getDoubleExtra("longitude",0);
		latitude_in = i_get.getDoubleExtra("latitude",0);
		address_in = i_get.getStringExtra("address");
		message_in = i_get.getStringExtra("description");
		image_in = i_get.getStringExtra("image");
	 	
		//BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
		mMap.addMarker(new MarkerOptions().position(new LatLng(latitude_in, longitude_in)).icon(BitmapDescriptorFactory.fromResource(R.drawable.doing)).
				title("Name : "+subject_in+"\n" + "Time : " + ins_time_in+" Date : "+ins_date_in+"\n"+"Address : "+address_in+"\n"+"Description : "+message_in));
		
		mMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(latitude_in, longitude_in)));
 }

	public void onMapLongClick(LatLng point) {
		// TODO Auto-generated method stub
		}
		@Override
		public boolean onKeyDown(int keyCode, KeyEvent event) {
		    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
		    	finish();
		        return true;		        
		    }
		    return super.onKeyDown(keyCode, event);
		}
	
}
