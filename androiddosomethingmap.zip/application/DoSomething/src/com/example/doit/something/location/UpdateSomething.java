package com.example.doit.something.location;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.*;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

public class UpdateSomething extends android.support.v4.app.FragmentActivity  {
	MapView mapUp;
	EditText txtSubjectUp, txtMessageUp, txtImageUp;
	TextView lblLocationUp;
	Button btnUpdateMapUp, btnBackUp;
	ImageButton imageUploadUp;
	
	MapController mc;
	RelativeLayout lytMapUp;
	Calendar c;
	static final int DATE_DIALOG_ID = 0;
	
    //static LocationManager locManager_ini;    
    LocationListener locationListener;
    
    int idUp;
    String idStringUp, subjectUp, ins_timeUp, ins_dateUp, messageUp, imageUp, latitude_inUp, longitude_inUp;
    String addressStringUp;
    String getTimeUp, getDateUp;
    
  //link localhost location for php in directory
    String url = "http://10.0.2.2/DoSomething/api-update.php";	
	SimpleDateFormat timeUp, dateUp;
	
	String updateDataUp;
	public static final int resultBackFile=1;
	public static final int resultBackCamera=2;
	private static final int SELECT_PICTURE = 1;
	private Uri imageUri;
	private String selectedImagePath;
    private String filemanagerstring;
	
	String imageFile, imagePath;
	File wallpaperDirectory;	
	
	LocationManager locationManager;
	Location location;
	
	private GoogleMap mMap;
	
	protected void onResume(){
		super.onResume();
		 posisiLokasi();
	}
	
	class MyInfoWindowAdapter implements InfoWindowAdapter{

        public final View myContentsView;
  
        MyInfoWindowAdapter(){
        	myContentsView = getLayoutInflater().inflate(R.layout.custom_info_window, null);
        }

		public View getInfoContents(Marker marker) {
			// TODO Auto-generated method stub	
			  TextView tvTitle = ((TextView)myContentsView.findViewById(R.id.title));
			  tvTitle.setText(marker.getTitle());
			  
			  return myContentsView;
		}

		public View getInfoWindow(Marker arg0) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	@SuppressLint("SdCardPath")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.updatesomething);
		
		txtSubjectUp = (EditText)findViewById(R.id.txtSubjectUp);
		txtMessageUp = (EditText)findViewById(R.id.txtMessageUp);
		txtImageUp = (EditText)findViewById(R.id.txtImageUp);
		imageUploadUp = (ImageButton)findViewById(R.id.imageUploadUp);		
		btnUpdateMapUp = (Button)findViewById(R.id.btnUpdateMapUp);
		lblLocationUp = (TextView)findViewById(R.id.lblLocationUp);
		btnBackUp = (Button)findViewById(R.id.btnBackUp);
		
		wallpaperDirectory = new File("/sdcard/DoSomethingApp/");
        wallpaperDirectory.mkdirs();
		
        Intent i_get = getIntent();
        idUp = i_get.getIntExtra("id",0);
		subjectUp = i_get.getStringExtra("subject");
		getDateUp = i_get.getStringExtra("ins_date");
		getTimeUp = i_get.getStringExtra("ins_time");
		addressStringUp = i_get.getStringExtra("address");
		messageUp = i_get.getStringExtra("description");
		imageUp = i_get.getStringExtra("image");
		btnBackUp = (Button)findViewById(R.id.btnBackUp);
        
		idStringUp = String.valueOf(idUp);
		
		c = Calendar.getInstance();
        timeUp = new SimpleDateFormat("HH:mm");
        dateUp = new SimpleDateFormat("dd-MM-yyyy");
        ins_timeUp = timeUp.format(c.getTime());
        ins_dateUp = dateUp.format(c.getTime());
		
        txtSubjectUp.setText(subjectUp);
        txtMessageUp.setText(messageUp);
        lblLocationUp.setText(addressStringUp);
        
		btnUpdateMapUp.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub			
				subjectUp = txtSubjectUp.getText().toString();
				messageUp = txtMessageUp.getText().toString();
				imageUp = txtImageUp.getText().toString();
				
				getDateUp = ins_dateUp;
				getTimeUp = ins_timeUp;
				
				if(subjectUp.equals("")||messageUp.equals("")||imageUp.equals("")){
					Toast.makeText(UpdateSomething.this, "Data not complete..", Toast.LENGTH_SHORT).show();
				}else{
					new UpdateData().execute(); 
					//Toast.makeText(UpdateSomething.this, idStringUp+"\n"+ins_timeUp+"\n"+ins_dateUp+"\n"+subjectUp+"\n"+messageUp+"\n"+longitude_inUp+"\n"+latitude_inUp+"\n"+imageUp, Toast.LENGTH_LONG).show();
					
					
				}
				
				
			}
		});
		
		imageUploadUp.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				chooseImage();
			}
		});
		
		btnBackUp.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		posisiLokasi();
	}
	
	public void posisiLokasi(){
		
	     // Do a null check to confirm that we have not already instantiated the map.
	     if (mMap == null) {
	         // Try to obtain the map from the SupportMapFragment.
	         mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
	                 .getMap();


	         mMap.setMyLocationEnabled(true);
	         mMap.getUiSettings().setZoomControlsEnabled(true);
	         mMap.getUiSettings().setCompassEnabled(true);
	         mMap.getUiSettings().setMyLocationButtonEnabled(true);
	         
	         mMap.getUiSettings().setRotateGesturesEnabled(true);
	         mMap.getUiSettings().setScrollGesturesEnabled(true);
	         mMap.getUiSettings().setTiltGesturesEnabled(true);
	         mMap.getUiSettings().setZoomGesturesEnabled(true);
	         mMap.setTrafficEnabled(true);
	         
	         mMap.setInfoWindowAdapter(new MyInfoWindowAdapter());
	         
	         // Check if we were successful in obtaining the map.
	         if (mMap != null) {		            
	             setUpMap();
	         }
	     }
	}
	
	public void setUpMap() {	 	

   	 LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
   	 Criteria criteria = new Criteria();
   	 String provider = service.getBestProvider(criteria, false);
   	 location = service.getLastKnownLocation(provider);
   	 LatLng userLocation = new LatLng(location.getLatitude(),location.getLongitude());
   	 
   	 //To Get Address
   	Geocoder gc = new Geocoder(this, Locale.getDefault());
    try {
      List<Address> addresses = gc.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
      StringBuilder sb = new StringBuilder();
      if (addresses.size() > 0) {
        Address address = addresses.get(0);

        for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
        sb.append(address.getAddressLine(i)).append(", "); 	
        sb.append(address.getCountryName());
        
      }
      addressStringUp = sb.toString();
    } catch (IOException e) {
    }
	lblLocationUp.setText(addressStringUp);
	//Toast.makeText(UpdateSomething.this,addressStringUp, Toast.LENGTH_SHORT).show();
	//To get Address
   	 
	//BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
	mMap.addMarker(new MarkerOptions().position(userLocation).icon(BitmapDescriptorFactory.fromResource(R.drawable.doing)).
		title("Your Locations"));
		
	mMap.animateCamera(CameraUpdateFactory.newLatLng(userLocation)); 
 }
        
	 public void UpdateSomethingData(){    	
		 latitude_inUp = String.valueOf( location.getLatitude());
		 longitude_inUp = String.valueOf(location.getLongitude());
		 
		updateDataUp = getRequestUpdate(idStringUp, subjectUp, ins_dateUp, ins_timeUp, longitude_inUp, latitude_inUp, addressStringUp, messageUp, imagePath, url);
	 }
    	
    	// code for get all data from sdcard
    	  @SuppressWarnings("deprecation")
		public String getPath(Uri uri) {
    	        String[] projection = { MediaStore.Images.Media.DATA };
    	        Cursor cursor = managedQuery(uri, projection, null, null, null);
    	        if(cursor!=null)
    	        {   //HERE YOU WILL GET A NULLPOINTER IF CURSOR IS NULL
    	            //THIS CAN BE, IF YOU USED OI FILE MANAGER FOR PICKING THE MEDIA
    	            int column_index = cursor
    	            .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
    	            cursor.moveToFirst();
    	            return cursor.getString(column_index);
    	        }
    	        else return null;
    	    }
        
    	  // code for selected image from camera or album

    	public void chooseImage(){
        	final CharSequence[] AlbumPhoto = {"Image Album", "Take a photo"};
        	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        	builder.setIcon(R.drawable.picture);
        	builder.setTitle("Select Photo");
        	builder.setItems(AlbumPhoto, new DialogInterface.OnClickListener() {
        	    public void onClick(DialogInterface dialog, int item) {
        	        //Toast.makeText(getApplicationContext(), FlowerPhoto[item], Toast.LENGTH_SHORT).show();
        	    	if(AlbumPhoto[item]=="Image Album"){
            			Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent,"Select Picture"), SELECT_PICTURE);
            		}else if(AlbumPhoto[item]=="Take a photo"){
            			takePhoto(resultBackCamera);
            		}
            		dialog.dismiss();
        	    }
        	});
        	AlertDialog alert = builder.create();
        	alert.show();       
    	}
    	
    	// code for save image from camera into /sdcard/DoSomethingApp
    	
    	 @SuppressLint("SdCardPath")
		public void takePhoto(int resultbackcamera2) {
    	    	String folder = "/sdcard/DoSomethingApp/";
    	        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
    	        Random generator = new Random();
    	        int n = 10000;
    	        n = generator.nextInt(n);
    	        String fname = "DoSomething-"+ n +".jpg";
    	        File photo = new File(folder, fname );
    	        intent.putExtra(MediaStore.EXTRA_OUTPUT,
    	                Uri.fromFile(photo));
    	        imageUri = Uri.fromFile(photo);
    	        startActivityForResult(intent, resultBackCamera);
    	    }
    	 
    	 protected void onActivityResult(int requestCode, int resultCode, Intent data)
    	    {
    	        switch(requestCode) {
    	        case resultBackFile:
    	        	if (resultCode == Activity.RESULT_OK) {
    	        		imageUploadUp = (ImageButton) findViewById(R.id.imageUploadUp);
    	        		txtImageUp = (EditText)findViewById(R.id.txtImageUp);
    	        		
    		        	imageUri = data.getData();
    		            //OI FILE Manager
    		            filemanagerstring = imageUri.getPath();
    		            //MEDIA GALLERY
    		            selectedImagePath = getPath(imageUri);
    		            //DEBUG PURPOSE - you can delete this if you want
    		            if(selectedImagePath!=null)
    		                System.out.println(selectedImagePath);
    		            else System.out.println("selectedImagePath is null");
    		            if(filemanagerstring!=null)
    		                System.out.println(filemanagerstring);
    		            else System.out.println("filemanagerstring is null");
    		            //NOW WE HAVE OUR WANTED STRING
    		            if(selectedImagePath!=null)
    		                System.out.println("selectedImagePath is the right one for you!");
    		            else
    		                System.out.println("filemanagerstring is the right one for you!");
    		            
    	            	BitmapFactory.Options options = new BitmapFactory.Options();
    	    	        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
    	    	        Bitmap bitmap = BitmapFactory.decodeFile(selectedImagePath, options);
    	    	        imageUploadUp.setImageBitmap(bitmap);
    	    	        imageUploadUp.setScaleType(ImageView.ScaleType.FIT_XY);
    		            //Toast.makeText(getApplicationContext(),selectedImagePath, Toast.LENGTH_SHORT).show();
    		            imagePath = selectedImagePath;
    		            txtImageUp.setText(imagePath);	
    		            
    		        	}
    	        	break;
    	        	
    	        case resultBackCamera:
    	        	if (resultCode == Activity.RESULT_OK) {
    	                Uri selectedImage = imageUri;
    	                getContentResolver().notifyChange(selectedImage, null);
    	                imageUploadUp = (ImageButton) findViewById(R.id.imageUploadUp);
    	                txtImageUp = (EditText)findViewById(R.id.txtImageUp);
    	                
    	                ContentResolver cr = getContentResolver();
    	                Bitmap bitmap;
    	                try {
    	                     bitmap = android.provider.MediaStore.Images.Media
    	                     .getBitmap(cr, selectedImage);
    	                    imageUploadUp.setImageBitmap(bitmap);
    	                    imageUploadUp.setScaleType(ImageView.ScaleType.FIT_XY);
    	                    //Toast.makeText(this, selectedImage.toString(), Toast.LENGTH_LONG).show();
    	                } catch (Exception e) {
    	                    //Toast.makeText(this, "Failed to load", Toast.LENGTH_SHORT).show();
    	                    Log.e("Camera", e.toString());
    	                }
    	                imagePath = selectedImage.toString();
    	                imagePath = imagePath.substring(7);
    	                txtImageUp.setText(imagePath);
    	            }
    	        	break;
    	        }    
    	    }
    	 
    	 @Override
    		public void onConfigurationChanged(final Configuration newConfig)
    		{
    		    // Ignore orientation change to keep activity from restarting
    		    super.onConfigurationChanged(newConfig);
    		}
    		public class UpdateData extends AsyncTask<Void, Void, Void> {
    			ProgressDialog dialog;
    			
    			@Override
    			 protected void onPreExecute() {
    			  // TODO Auto-generated method stub
    				 dialog= ProgressDialog.show(UpdateSomething.this, "", 
    		                 "Update data..., please wait...", true);
    			 }

    			 @Override
    			 protected Void doInBackground(Void... params) {
    			  // TODO Auto-generated method stub
    				 //InsertData();
    				 UpdateSomethingData();
    			  return null;
    			 }

    			@Override
    			protected void onPostExecute(Void result) {
    				// TODO Auto-generated method stub
    				dialog.dismiss();
    				Toast.makeText(UpdateSomething.this, "Update Data Succesfuly", Toast.LENGTH_SHORT).show();
    			}
    		}
    		
    		public String getRequestUpdate(String id, String subject, String ins_date, String ins_time, String longitude ,String latitude, String address, String description, String image, String Url){
    			HttpURLConnection connection = null;
    			DataOutputStream outputStream = null;
    			String pathToOurFile = image;
    			String urlServer = Url;
    			String lineEnd = "\r\n";
    			String twoHyphens = "--";
    			String boundary =  "*****";

    			String serverResponseMessage = null;
    			int bytesRead, bytesAvailable, bufferSize;
    			byte[] buffer;
    			int maxBufferSize = 1*1024*1024;

    			try
    			{
    			FileInputStream fileInputStream = new FileInputStream(new File(pathToOurFile) );

    			URL url = new URL(urlServer);
    			connection = (HttpURLConnection) url.openConnection();

    			// Allow Inputs & Outputs
    			connection.setDoInput(true);
    			connection.setDoOutput(true);
    			connection.setUseCaches(false);

    			// Enable POST method
    			connection.setRequestMethod("POST");

    			connection.setRequestProperty("Connection", "Keep-Alive");
    			connection.setRequestProperty("Content-Type", "multipart/form-data;boundary="+boundary);

    			outputStream = new DataOutputStream( connection.getOutputStream() );
    			outputStream.writeBytes(twoHyphens + boundary + lineEnd);
    			outputStream.writeBytes("Content-Disposition: form-data; name=\"uploadedfile\";filename=\"" + pathToOurFile +"\"" + lineEnd);
    			outputStream.writeBytes(lineEnd);

    			bytesAvailable = fileInputStream.available();
    			bufferSize = Math.min(bytesAvailable, maxBufferSize);
    			buffer = new byte[bufferSize];

    			// Read file
    			bytesRead = fileInputStream.read(buffer, 0, bufferSize);

    			while (bytesRead > 0)
    			{
    			outputStream.write(buffer, 0, bufferSize);
    			bytesAvailable = fileInputStream.available();
    			bufferSize = Math.min(bytesAvailable, maxBufferSize);
    			bytesRead = fileInputStream.read(buffer, 0, bufferSize);
    			}

    			outputStream.writeBytes(lineEnd);
    			outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

    			serverResponseMessage = connection.getResponseMessage();

    			fileInputStream.close();
    			outputStream.flush();
    			outputStream.close();
    			
    			String hasil = "";
    			Log.d("getRequest",urlServer);
    			HttpClient client = new DefaultHttpClient();
    	        HttpPost request = new HttpPost(urlServer);
    	        
    	        try{
    	        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(9);
    	        	nameValuePairs.add(new BasicNameValuePair("id", id));
    	            nameValuePairs.add(new BasicNameValuePair("subject", subject));
    	            nameValuePairs.add(new BasicNameValuePair("ins_date", ins_date));
    	            nameValuePairs.add(new BasicNameValuePair("ins_time", ins_time));
    	            nameValuePairs.add(new BasicNameValuePair("longitude", longitude));
    	            nameValuePairs.add(new BasicNameValuePair("latitude", latitude));
    	            nameValuePairs.add(new BasicNameValuePair("address", address));
    	            nameValuePairs.add(new BasicNameValuePair("description", description));
    	            nameValuePairs.add(new BasicNameValuePair("image", image));
    	            request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
    	        	HttpResponse response = client.execute(request);
    	            hasil = request(response);
    	        }catch(Exception ex){
    	        	hasil = "Failed Connect to server!";
    	        }
    	        return hasil;
    			
    			}
    			catch (Exception ex)
    			{
    			//Exception handling
    			}
    			
    			return serverResponseMessage+image;
    		}
    		
    		public static String request(HttpResponse response){
    		    String result = "";
    		    try{
    		        InputStream in = response.getEntity().getContent();
    		        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
    		        StringBuilder str = new StringBuilder();
    		        String line = null;
    		        while((line = reader.readLine()) != null){
    		            str.append(line + "\n");
    		        }
    		        in.close();
    		        result = str.toString();
    		    }catch(Exception ex){
    		        result = "Error";
    		    }
    		    return result;
    		}
}

