/** Automatically generated file. DO NOT MODIFY */
package com.example.doit.something.location;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}